# Responsive Food Landing Page Using HTML CSS Javascript
 
## Video

In this video, I will show you how to make Responsive Food Landing Page  with awesome animation just by using HTML, CSS and JavaScript.

https://youtu.be/_A7diZfXMkc

!["Responsive Food Landing Page Using HTML CSS Javascript"](https://raw.githubusercontent.com/trananhtuat/responsive-animate-food-landing-page/main/banner.png "Responsive Food Landing Page Using HTML CSS Javascript")

!["Responsive Food Landing Page Using HTML CSS Javascript"](https://raw.githubusercontent.com/trananhtuat/responsive-animate-food-landing-page/main/screencapture-file-D-projectsv2-food-landing-page-index-html-2020-11-19-15_09_23.png "Responsive Food Landing Page Using HTML CSS Javascript")